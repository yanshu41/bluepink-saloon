BluPink Unisex Salon — Demo Website

Files:
- index.html: website content
- style.css: responsive layout and visual styling
- script.js: mobile navigation interaction

How to preview:
1. Extract the ZIP file.
2. Open index.html in Chrome or another browser.
3. For editing, open the folder in Visual Studio Code.

Before showing/publishing to the business:
- This is an independent demo concept, not an official BluPink website.
- Confirm the business owner wants a website and has authorized use of its name, photos, logos, and reviews.
- Replace the abstract CSS artwork with licensed/owner-approved salon photos if desired.
- Confirm all services, phone numbers, address, hours, and review permissions.
- Confirm the second phone number (7011253538) with the business before adding it.
- No prices are invented; call to confirm current rates.
- The listed review excerpts were supplied by the requester. Verify exact wording and permission before publishing.
- This project uses Google Fonts over the internet; the layout still works if they do not load.

The website uses tel: links and a Google Maps search link. It does not contain a booking backend or collect customer information.
